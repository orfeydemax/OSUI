# SERVER_ACCESS_SOP.private.template.md

## Назначение
Это **приватный шаблон** для серверного доступа.  
Заполняется локально. Не должен хранить реальные пароли и чувствительные значения в versioned repo.

## Статус файла
- Этот файл можно использовать как шаблон.
- Реальный рабочий файл должен быть:
  - либо в локальном private-контуре;
  - либо в защищённом хранилище;
  - либо в `.gitignore`.

## Поля для локального заполнения

### Сервер
- host:
- ssh_port:
- primary_user:
- access_method:
- notes:

### SSH
- private_key_path:
- strict_host_key_policy:
- default_login_command_template:

### Privileged access
- escalate_method: `sudo` / `sudo -i` / другое
- ask_first_required: yes
- when_root_or_privileged_is_allowed:
- what_must_be_confirmed_before_privileged_actions:

### Deployment notes
- where_apps_run:
- which apps run under deploy:
- which apps historically ran elsewhere:
- safe_working_directory:
- docker_or_process_notes:

### Secrets
- secret_source: vault / local secure store / другое
- env_policy:
- forbidden_secret_locations:

## Обязательные правила
- Никогда не хранить реальные пароли в versioned repo.
- Никогда не тащить чувствительные значения в глобальный `GEMINI.md`.
- Любой privileged access — только после ask-first.
- Если для задачи нужен секрет, агент сначала просит разрешение и указывает цель использования.

## Что можно хранить в этом шаблоне
- общую процедуру;
- типовые команды-шаблоны без чувствительных значений;
- указание, где искать локальный SOP.

## Что нельзя хранить
- реальные пароли;
- токены;
- приватные ключи;
- содержимое credential-файлов;
- резервные чувствительные данные “на всякий случай”.
