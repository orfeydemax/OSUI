# ANTIGRAVITY_TASK_GEMINI_REFACTOR.md

Работай строго по этой задаче.  
Цель: перепаковать глобальный `GEMINI.md` в безопасную структуру под OSUI V9.1.

## Что нужно сделать

### 1. Заменить глобальный `GEMINI.md`
- Сократи его до глобального policy-слоя.
- Оставь только:
  - язык human-readable слоя;
  - ask-first для privileged actions;
  - self-annealing loop;
  - repo-local truth;
  - planning discipline;
  - skill/workflow/agent declaration;
  - запрет на симуляцию capability;
  - safe brownfield discipline;
  - context discipline;
  - правило, что секреты и server SOP не живут в глобальном файле.

### 2. Создать отдельный файл:
- `directives/EXPLANATION_STYLE.md`

Туда вынеси:
- стиль объяснений;
- формат “аналогия → структура → шаги → ошибки → надёжность”;
- требования к простому языку.

### 3. Создать отдельный файл:
- `directives/SERVER_ACCESS_SOP.private.template.md`

Туда вынеси:
- шаблон серверного SOP;
- только безопасный каркас;
- без реальных паролей, токенов и чувствительных значений.

### 4. Создать отдельный файл:
- `directives/SECRETS_AND_VAULT_POLICY.md`

Туда вынеси:
- правила хранения секретов;
- запрет на хранение чувствительных значений в `GEMINI.md`;
- правила ask-first и vault usage.

## Жёсткие запреты
- не переноси реальные пароли и чувствительные значения в новые файлы;
- не тащи серверные секреты в versioned repo;
- не превращай новый `GEMINI.md` в энциклопедию;
- не меняй workflow-файлы в рамках этой задачи;
- не переписывай лишние документы.

## Что нужно проверить перед завершением
1. Новый `GEMINI.md` короче и чище старого.
2. Стиль объяснений живёт отдельно.
3. Серверный SOP вынесен отдельно и не содержит секретов.
4. В `GEMINI.md` нет:
   - реальных паролей;
   - приватных ключей;
   - чувствительных путей как обязательной глобальной истины.
5. Новый набор не конфликтует с V9.1 принципами:
   - ask-first;
   - repo-local truth;
   - safe brownfield change;
   - context discipline.

## Выход
В конце выдай:

### Created files
### Updated files
### Sensitive content removed or externalized
### Open questions
### Why this refactor is safer and cleaner now

Не используй слова:
- “почти”
- “в целом”
- “логически”

Пиши только по факту.
